package com.iraqi.buffalo;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class WindFanBlockEntity extends BlockEntity {
    public static final int ENERGY_PER_TICK = 10;   // FE/t when powered by energy instead of redstone
    public static final int RANGE = 6;              // blocks of wind in front of the fan
    public static final int GROW_BOOST = 3;         // extra age ticks per tick -> baby grows 4x faster

    public final PotEnergy energy = new PotEnergy(10000, 1000);
    private int soundTimer;

    // client-side blade animation
    public float angle;
    public float angleO;

    public WindFanBlockEntity(BlockPos pos, BlockState state) {
        super(IraqiBuffaloMod.WIND_FAN_BE.get(), pos, state);
    }

    public boolean hasPower(Level level, BlockPos pos) {
        return level.hasNeighborSignal(pos) || this.energy.getEnergyStored() >= ENERGY_PER_TICK;
    }

    /** Free blocks in front of the fan (a full block stops the wind). */
    public static int windLength(Level level, BlockPos pos, Direction dir) {
        int n = 0;
        for (int i = 1; i <= RANGE; i++) {
            BlockPos p = pos.relative(dir, i);
            if (level.getBlockState(p).isCollisionShapeFullBlock(level, p)) break;
            n = i;
        }
        return n;
    }

    /** 3 blocks wide, 3 blocks high, {@code len} blocks long, starting right in front of the fan. */
    public static AABB windBox(BlockPos pos, Direction dir, int len) {
        double minX = pos.getX() - 1, maxX = pos.getX() + 2;
        double minY = pos.getY() - 1, maxY = pos.getY() + 2;
        double minZ = pos.getZ() - 1, maxZ = pos.getZ() + 2;
        boolean pos_ = dir.getAxisDirection() == Direction.AxisDirection.POSITIVE;
        switch (dir.getAxis()) {
            case X -> { minX = pos_ ? pos.getX() + 1 : pos.getX() - len; maxX = pos_ ? pos.getX() + 1 + len : pos.getX(); }
            case Y -> { minY = pos_ ? pos.getY() + 1 : pos.getY() - len; maxY = pos_ ? pos.getY() + 1 + len : pos.getY(); }
            case Z -> { minZ = pos_ ? pos.getZ() + 1 : pos.getZ() - len; maxZ = pos_ ? pos.getZ() + 1 + len : pos.getZ(); }
        }
        return new AABB(minX, minY, minZ, maxX, maxY, maxZ);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, WindFanBlockEntity be) {
        boolean redstone = level.hasNeighborSignal(pos);
        boolean powered = redstone || be.energy.getEnergyStored() >= ENERGY_PER_TICK;
        boolean lit = state.getValue(WindFanBlock.LIT);

        if (!powered) {
            be.soundTimer = 0;
            if (lit) level.setBlock(pos, state.setValue(WindFanBlock.LIT, false), 3);
            return;
        }
        if (!redstone) be.energy.consume(ENERGY_PER_TICK);
        if (!lit) level.setBlock(pos, state.setValue(WindFanBlock.LIT, true), 3);

        if (--be.soundTimer <= 0) {
            be.soundTimer = 40;
            level.playSound(null, pos, IraqiBuffaloMod.FAN_HUM.get(), SoundSource.BLOCKS, 0.6F, 1.0F);
        }

        Direction dir = state.getValue(WindFanBlock.FACING);
        int len = windLength(level, pos, dir);
        if (len <= 0) return;
        AABB box = windBox(pos, dir, len);

        // push everything in the wind
        double strength = dir.getAxis() == Direction.Axis.Y ? 0.14D : 0.09D;
        Vec3 step = new Vec3(dir.getStepX(), dir.getStepY(), dir.getStepZ());
        for (Entity e : level.getEntities((Entity) null, box, WindFanBlockEntity::canPush)) {
            Vec3 v = e.getDeltaMovement();
            if (v.dot(step) < 0.5D) {
                e.setDeltaMovement(v.add(step.scale(strength)));
                e.hasImpulse = true;
                if (e instanceof Player) e.hurtMarked = true; // sync the push to the client
            }
        }

        // baby buffalo in the wind grow 4x faster (natural +1/tick, fan adds +3/tick)
        if (level.getGameTime() % 5 == 0) {
            for (IraqiBuffalo baby : level.getEntitiesOfClass(IraqiBuffalo.class, box, IraqiBuffalo::isBaby)) {
                baby.setAge(Math.min(0, baby.getAge() + GROW_BOOST * 5));
            }
        }
    }

    private static boolean canPush(Entity e) {
        if (e.isSpectator() || e.isPassenger()) return false;
        if (e instanceof Player p && (p.getAbilities().flying || p.isShiftKeyDown())) return false;
        return true;
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, WindFanBlockEntity be) {
        be.angleO = be.angle;
        if (!state.getValue(WindFanBlock.LIT)) return;
        be.angle = (be.angle + 25.0F) % 360.0F;
        if (level.getGameTime() % 2 == 0) {
            Direction dir = state.getValue(WindFanBlock.FACING);
            int len = windLength(level, pos, dir);
            if (len <= 0) return;
            var r = level.random;
            double along = 0.7D + r.nextDouble() * Math.max(0.5D, len - 0.7D);
            double x = pos.getX() + 0.5D + dir.getStepX() * along + (dir.getStepX() == 0 ? (r.nextDouble() - 0.5D) * 2.4D : 0);
            double y = pos.getY() + 0.5D + dir.getStepY() * along + (dir.getStepY() == 0 ? (r.nextDouble() - 0.5D) * 2.4D : 0);
            double z = pos.getZ() + 0.5D + dir.getStepZ() * along + (dir.getStepZ() == 0 ? (r.nextDouble() - 0.5D) * 2.4D : 0);
            level.addParticle(ParticleTypes.CLOUD, x, y, z, dir.getStepX() * 0.25D, dir.getStepY() * 0.25D, dir.getStepZ() * 0.25D);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
    }
}

package com.iraqi.buffalo.goal;

import com.iraqi.buffalo.IraqiBuffaloMod;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Added to vanilla pigs: walk to buffalo dung lying on the ground and eat it. */
public class PigEatDungGoal extends Goal {
    private final Pig pig;
    private ItemEntity target;

    public PigEatDungGoal(Pig pig) {
        this.pig = pig;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    private static boolean isDung(ItemEntity e) {
        return e.isAlive() && e.getItem().is(IraqiBuffaloMod.BUFFALO_DUNG.get());
    }

    @Override
    public boolean canUse() {
        if (pig.getRandom().nextInt(10) != 0) return false;
        List<ItemEntity> list = pig.level().getEntitiesOfClass(ItemEntity.class,
                pig.getBoundingBox().inflate(10.0D, 3.0D, 10.0D), PigEatDungGoal::isDung);
        if (list.isEmpty()) return false;
        list.sort(Comparator.comparingDouble(pig::distanceToSqr));
        target = list.get(0);
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && isDung(target);
    }

    @Override
    public void start() {
        pig.getNavigation().moveTo(target, 1.1D);
    }

    @Override
    public void stop() {
        target = null;
        pig.getNavigation().stop();
    }

    @Override
    public void tick() {
        pig.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (pig.distanceToSqr(target) < 2.25D) {
            ItemStack stack = target.getItem();
            stack.shrink(1);
            if (stack.isEmpty()) target.discard(); else target.setItem(stack);
            pig.heal(2.0F);
            pig.playSound(SoundEvents.GENERIC_EAT, 1.0F, 1.0F);
            target = null;
        } else if (pig.getNavigation().isDone()) {
            pig.getNavigation().moveTo(target, 1.1D);
        }
    }
}

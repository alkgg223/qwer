package com.iraqi.buffalo.client;

import com.iraqi.buffalo.IraqiBuffaloMod;
import com.iraqi.buffalo.WindFanBlock;
import com.iraqi.buffalo.WindFanBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Draws the spinning blades of the wind fan (the casing is a normal JSON block model). */
public class WindFanRenderer implements BlockEntityRenderer<WindFanBlockEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(IraqiBuffaloMod.MODID, "wind_fan_blades"), "main");
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(IraqiBuffaloMod.MODID, "textures/block/wind_fan_blades.png");

    private final ModelPart rotor;

    public WindFanRenderer(BlockEntityRendererProvider.Context ctx) {
        this.rotor = ctx.bakeLayer(LAYER).getChild("rotor");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition rotor = mesh.getRoot().addOrReplaceChild("rotor", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-1.5F, -1.5F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        for (int i = 0; i < 4; i++) {
            rotor.addOrReplaceChild("blade" + i, CubeListBuilder.create()
                    .texOffs(0, 8).addBox(1.0F, -1.75F, -0.5F, 5.0F, 3.5F, 1.0F),
                    PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.35F, 0.0F, i * Mth.HALF_PI));
        }
        return LayerDefinition.create(mesh, 32, 32);
    }

    @Override
    public void render(WindFanBlockEntity be, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight, int packedOverlay) {
        Direction dir = be.getBlockState().getValue(WindFanBlock.FACING);
        float angle = Mth.lerp(partialTick, be.angleO, be.angle);
        poseStack.pushPose();
        poseStack.translate(0.5D, 0.5D, 0.5D);
        // the model's front (air outlet) is NORTH; rotate it to the fan's facing
        if (dir == Direction.UP) {
            poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
        } else if (dir == Direction.DOWN) {
            poseStack.mulPose(Axis.XP.rotationDegrees(-90.0F));
        } else {
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - dir.toYRot()));
        }
        poseStack.scale(1.0F, -1.0F, -1.0F);
        this.rotor.zRot = angle * Mth.DEG_TO_RAD;
        this.rotor.render(poseStack, buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)),
                packedLight, packedOverlay);
        poseStack.popPose();
    }
}

package com.iraqi.buffalo.goal;

import com.iraqi.buffalo.IraqiBuffalo;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.MoveToBlockGoal;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Grazes fully grown wheat, carrots, potatoes and beetroots in farms (the crop regrows from age 0). */
public class BuffaloEatCropsGoal extends MoveToBlockGoal {
    private final IraqiBuffalo buffalo;

    public BuffaloEatCropsGoal(IraqiBuffalo buffalo) {
        super(buffalo, 1.0D, 14, 4);
        this.buffalo = buffalo;
    }

    @Override
    public boolean canUse() {
        if (buffalo.isLying() || buffalo.getTarget() != null) return false;
        if (!buffalo.level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return false;
        return super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        return !buffalo.isLying() && buffalo.getTarget() == null && super.canContinueToUse();
    }

    @Override
    protected int nextStartTick(PathfinderMob mob) {
        return reducedTickDelay(60 + mob.getRandom().nextInt(80));
    }

    @Override
    public double acceptedDistance() {
        return 2.0D;
    }

    private static boolean isEdible(BlockState state) {
        boolean allowed = state.is(Blocks.WHEAT) || state.is(Blocks.CARROTS)
                || state.is(Blocks.POTATOES) || state.is(Blocks.BEETROOTS);
        return allowed && state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state);
    }

    @Override
    protected boolean isValidTarget(LevelReader level, BlockPos pos) {
        if (!level.getBlockState(pos).is(Blocks.FARMLAND)) return false;
        return isEdible(level.getBlockState(pos.above()));
    }

    @Override
    public void tick() {
        super.tick();
        BlockPos cropPos = this.blockPos.above();
        buffalo.getLookControl().setLookAt(cropPos.getX() + 0.5D, cropPos.getY() + 0.5D,
                cropPos.getZ() + 0.5D, 10.0F, buffalo.getMaxHeadXRot());
        if (this.isReachedTarget()) {
            Level level = buffalo.level();
            BlockState state = level.getBlockState(cropPos);
            if (isEdible(state) && state.getBlock() instanceof CropBlock crop) {
                level.setBlock(cropPos, crop.getStateForAge(0), 2);
                level.levelEvent(2001, cropPos, Block.getId(state));
                buffalo.onAte(4.0F);
            }
        }
    }
}

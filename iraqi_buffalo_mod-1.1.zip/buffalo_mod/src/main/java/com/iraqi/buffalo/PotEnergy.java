package com.iraqi.buffalo;

import net.neoforged.neoforge.energy.EnergyStorage;

/** Small FE buffer for the Qaymar pot (can receive, cannot be drained from outside). */
public class PotEnergy extends EnergyStorage {
    public PotEnergy(int capacity, int maxReceive) {
        super(capacity, maxReceive, 0);
    }

    public void setEnergy(int value) {
        this.energy = Math.max(0, Math.min(this.capacity, value));
    }

    public boolean consume(int amount) {
        if (this.energy >= amount) {
            this.energy -= amount;
            return true;
        }
        return false;
    }
}

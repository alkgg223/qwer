package com.iraqi.buffalo.client;

import com.iraqi.buffalo.IraqiBuffalo;
import com.iraqi.buffalo.IraqiBuffaloMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Water buffalo model (texture layout 128x128). */
public class BuffaloModel extends EntityModel<IraqiBuffalo> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(IraqiBuffaloMod.MODID, "buffalo"), "main");

    private final ModelPart head, earL, earR, collar, body, hump, tail;
    private final ModelPart rightFront, leftFront, rightHind, leftHind;

    public BuffaloModel(ModelPart root) {
        this.head = root.getChild("head");
        this.earL = head.getChild("ear_l");
        this.earR = head.getChild("ear_r");
        this.collar = head.getChild("collar");
        this.body = root.getChild("body");
        this.hump = root.getChild("hump");
        this.tail = root.getChild("tail");
        this.rightFront = root.getChild("right_front_leg");
        this.leftFront = root.getChild("left_front_leg");
        this.rightHind = root.getChild("right_hind_leg");
        this.leftHind = root.getChild("left_hind_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-7.0F, 0.0F, -11.0F, 14.0F, 13.0F, 22.0F),
                PartPose.offset(0.0F, 2.0F, 2.0F));
        root.addOrReplaceChild("hump", CubeListBuilder.create()
                .texOffs(0, 36).addBox(-6.0F, -3.0F, -4.0F, 12.0F, 3.0F, 8.0F),
                PartPose.offset(0.0F, 2.0F, -3.0F));

        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0.0F, 10.0F, -8.0F, 0.25F, 0.0F, 0.0F));
        head.addOrReplaceChild("real_head", CubeListBuilder.create()
                .texOffs(0, 48).addBox(-5.5F, -5.0F, -9.0F, 11.0F, 10.0F, 9.0F)
                .texOffs(42, 48).addBox(-4.0F, 1.0F, -13.0F, 8.0F, 5.0F, 4.0F)
                .texOffs(68, 48).addBox(-6.5F, -7.0F, -5.0F, 13.0F, 2.0F, 3.0F), PartPose.ZERO);
        head.addOrReplaceChild("ear_l", CubeListBuilder.create()
                .texOffs(102, 48).addBox(0.0F, -0.5F, -1.5F, 4.0F, 1.0F, 3.0F),
                PartPose.offsetAndRotation(5.5F, -3.0F, -1.0F, 0.0F, 0.0F, 0.3F));
        head.addOrReplaceChild("ear_r", CubeListBuilder.create()
                .texOffs(102, 52).addBox(-4.0F, -0.5F, -1.5F, 4.0F, 1.0F, 3.0F),
                PartPose.offsetAndRotation(-5.5F, -3.0F, -1.0F, 0.0F, 0.0F, -0.3F));

        // bell collar (only visible when the buffalo wears one)
        head.addOrReplaceChild("collar", CubeListBuilder.create()
                .texOffs(0, 90).addBox(-6.0F, -5.5F, -3.0F, 12.0F, 11.0F, 2.0F)
                .texOffs(30, 90).addBox(-1.5F, 5.5F, -3.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);

        // horns: three segments curving outwards, backwards and upwards
        PartDefinition hornL = head.addOrReplaceChild("horn_l", CubeListBuilder.create()
                .texOffs(40, 58).addBox(0.0F, -1.5F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(7.0F, -6.0F, -3.5F, 0.0F, -0.3F, 0.0F));
        PartDefinition hornL2 = hornL.addOrReplaceChild("horn_l2", CubeListBuilder.create()
                .texOffs(58, 58).addBox(0.0F, -1.5F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.35F));
        hornL2.addOrReplaceChild("horn_l3", CubeListBuilder.create()
                .texOffs(76, 58).addBox(0.0F, -1.5F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5F));
        PartDefinition hornR = head.addOrReplaceChild("horn_r", CubeListBuilder.create()
                .texOffs(40, 64).addBox(-6.0F, -1.5F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(-7.0F, -6.0F, -3.5F, 0.0F, 0.3F, 0.0F));
        PartDefinition hornR2 = hornR.addOrReplaceChild("horn_r2", CubeListBuilder.create()
                .texOffs(58, 64).addBox(-6.0F, -1.5F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(-6.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.35F));
        hornR2.addOrReplaceChild("horn_r3", CubeListBuilder.create()
                .texOffs(76, 64).addBox(-6.0F, -1.5F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(-6.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 70).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 9.0F, 5.0F);
        root.addOrReplaceChild("right_front_leg", leg, PartPose.offset(-4.5F, 15.0F, -6.0F));
        root.addOrReplaceChild("left_front_leg", leg, PartPose.offset(4.5F, 15.0F, -6.0F));
        root.addOrReplaceChild("right_hind_leg", leg, PartPose.offset(-4.5F, 15.0F, 9.0F));
        root.addOrReplaceChild("left_hind_leg", leg, PartPose.offset(4.5F, 15.0F, 9.0F));

        PartDefinition tail = root.addOrReplaceChild("tail", CubeListBuilder.create()
                .texOffs(24, 70).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, 3.0F, 13.0F, 0.25F, 0.0F, 0.0F));
        tail.addOrReplaceChild("tuft", CubeListBuilder.create()
                .texOffs(34, 70).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F),
                PartPose.offset(0.0F, 10.0F, 0.0F));

        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(IraqiBuffalo e, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // smooth lie-down progress (0 = standing, 1 = lying)
        float lie = Mth.lerp(ageInTicks - e.tickCount, e.lieAnimO, e.lieAnim);
        lie = lie * lie * (3.0F - 2.0F * lie);

        float bodyY = Mth.lerp(lie, 2.0F, 10.0F);
        body.y = bodyY;
        hump.y = bodyY;
        head.y = Mth.lerp(lie, 10.0F, 18.0F);
        tail.y = Mth.lerp(lie, 3.0F, 11.0F);

        float pitch = 0.25F + headPitch * Mth.DEG_TO_RAD - lie * 0.35F;
        if (e.isAggressive()) pitch += 0.35F;
        pitch += e.getEatAnim() * 0.9F;
        head.xRot = pitch;
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD * (1.0F - lie * 0.5F);

        collar.visible = e.hasCollar();

        float flick = Mth.sin(ageInTicks * 0.15F) * 0.1F;
        earL.zRot = 0.3F + flick;
        earR.zRot = -0.3F - flick;

        tail.xRot = 0.25F + Mth.sin(ageInTicks * 0.1F) * 0.08F;
        tail.zRot = Mth.sin(ageInTicks * 0.13F) * 0.12F;

        float swing = 0.9F * limbSwingAmount * (1.0F - lie);
        float t = limbSwing * 0.6662F;
        float legY = Mth.lerp(lie, 15.0F, 21.0F);
        float fold = -1.45F;
        rightHind.y = leftHind.y = rightFront.y = leftFront.y = legY;
        rightHind.xRot = Mth.lerp(lie, Mth.cos(t) * swing, fold);
        leftHind.xRot = Mth.lerp(lie, Mth.cos(t + Mth.PI) * swing, fold);
        rightFront.xRot = Mth.lerp(lie, Mth.cos(t + Mth.PI) * swing, fold);
        leftFront.xRot = Mth.lerp(lie, Mth.cos(t) * swing, fold);
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, int color) {
        head.render(ps, vc, light, overlay, color);
        body.render(ps, vc, light, overlay, color);
        hump.render(ps, vc, light, overlay, color);
        rightFront.render(ps, vc, light, overlay, color);
        leftFront.render(ps, vc, light, overlay, color);
        rightHind.render(ps, vc, light, overlay, color);
        leftHind.render(ps, vc, light, overlay, color);
        tail.render(ps, vc, light, overlay, color);
    }
}

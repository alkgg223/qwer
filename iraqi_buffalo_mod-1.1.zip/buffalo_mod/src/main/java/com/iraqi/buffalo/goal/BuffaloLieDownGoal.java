package com.iraqi.buffalo.goal;

import com.iraqi.buffalo.IraqiBuffalo;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/** Randomly lies down to rest (more often at night). Any damage or target makes it stand up. */
public class BuffaloLieDownGoal extends Goal {
    private final IraqiBuffalo buffalo;
    private int timer;

    public BuffaloLieDownGoal(IraqiBuffalo buffalo) {
        this.buffalo = buffalo;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        if (!buffalo.onGround() || buffalo.isLying() || buffalo.getTarget() != null || buffalo.isInLove()) return false;
        int chance = buffalo.level().isNight() ? 150 : 450;
        return buffalo.getRandom().nextInt(reducedTickDelay(chance)) == 0;
    }

    @Override
    public boolean canContinueToUse() {
        return timer > 0 && buffalo.isLying() && buffalo.getTarget() == null;
    }

    @Override
    public void start() {
        buffalo.setLying(true);
        buffalo.getNavigation().stop();
        timer = 200 + buffalo.getRandom().nextInt(400);
    }

    @Override
    public void tick() {
        timer--;
    }

    @Override
    public void stop() {
        buffalo.setLying(false);
    }
}

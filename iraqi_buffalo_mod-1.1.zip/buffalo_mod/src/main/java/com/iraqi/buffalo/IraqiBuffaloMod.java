package com.iraqi.buffalo;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.animal.Pig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import com.iraqi.buffalo.goal.PigEatDungGoal;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(IraqiBuffaloMod.MODID)
public class IraqiBuffaloMod {
    public static final String MODID = "iraqi_buffalo";

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(BuiltInRegistries.SOUND_EVENT, MODID);
    private static DeferredHolder<SoundEvent, SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(MODID, name)));
    }
    public static final DeferredHolder<SoundEvent, SoundEvent> BUFFALO_AMBIENT = sound("buffalo_ambient");
    public static final DeferredHolder<SoundEvent, SoundEvent> BUFFALO_HURT = sound("buffalo_hurt");
    public static final DeferredHolder<SoundEvent, SoundEvent> BUFFALO_DEATH = sound("buffalo_death");
    public static final DeferredHolder<SoundEvent, SoundEvent> COLLAR_BELL = sound("collar_bell");
    public static final DeferredHolder<SoundEvent, SoundEvent> FAN_HUM = sound("fan_hum");

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, MODID);
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<IraqiBuffalo>> BUFFALO =
            ENTITIES.register("buffalo", () -> EntityType.Builder
                    .of(IraqiBuffalo::new, MobCategory.CREATURE)
                    .sized(1.5F, 1.6F)
                    .eyeHeight(1.0F)
                    .clientTrackingRange(10)
                    .build("buffalo"));

    // ---- machine: electric rotating qaymar pot ----
    public static final DeferredBlock<QaymarPotBlock> QAYMAR_POT = BLOCKS.registerBlock("qaymar_pot",
            QaymarPotBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0F, 6.0F)
                    .sound(SoundType.METAL).noOcclusion());

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<QaymarPotBlockEntity>> QAYMAR_POT_BE =
            BLOCK_ENTITIES.register("qaymar_pot", () -> BlockEntityType.Builder
                    .of(QaymarPotBlockEntity::new, QAYMAR_POT.get()).build(null));

    // ---- machine: wind fan ----
    public static final DeferredBlock<WindFanBlock> WIND_FAN = BLOCKS.registerBlock("wind_fan",
            WindFanBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0F, 6.0F)
                    .sound(SoundType.METAL).noOcclusion());

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<WindFanBlockEntity>> WIND_FAN_BE =
            BLOCK_ENTITIES.register("wind_fan", () -> BlockEntityType.Builder
                    .of(WindFanBlockEntity::new, WIND_FAN.get()).build(null));

    // ---- items ----
    public static final DeferredItem<BlockItem> WIND_FAN_ITEM =
            ITEMS.register("wind_fan", () -> new BlockItem(WIND_FAN.get(), new Item.Properties()));

    public static final DeferredItem<Item> BUFFALO_COLLAR =
            ITEMS.register("buffalo_collar", () -> new Item(new Item.Properties().stacksTo(16)));

    public static final DeferredItem<Item> BUFFALO_DUNG =
            ITEMS.register("buffalo_dung", () -> new Item(new Item.Properties()));

    public static final DeferredItem<BlockItem> QAYMAR_POT_ITEM =
            ITEMS.register("qaymar_pot", () -> new BlockItem(QAYMAR_POT.get(), new Item.Properties()));

    public static final DeferredItem<Item> BUFFALO_MILK_BUCKET =
            ITEMS.register("buffalo_milk_bucket",
                    () -> new Item(new Item.Properties().stacksTo(1).craftRemainder(Items.BUCKET)));

    public static final DeferredItem<QaymarItem> QAYMAR =
            ITEMS.register("qaymar",
                    () -> new QaymarItem(new Item.Properties().stacksTo(16).food(QaymarItem.FOOD)));

    public static final DeferredItem<DeferredSpawnEggItem> BUFFALO_SPAWN_EGG =
            ITEMS.register("buffalo_spawn_egg",
                    () -> new DeferredSpawnEggItem(BUFFALO, 0x3A3835, 0xB8A98A, new Item.Properties()));

    public IraqiBuffaloMod(IEventBus modBus) {
        SOUNDS.register(modBus);
        ENTITIES.register(modBus);
        BLOCKS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        ITEMS.register(modBus);
        modBus.addListener(this::registerAttributes);
        modBus.addListener(this::registerSpawnPlacements);
        modBus.addListener(this::registerCapabilities);
        modBus.addListener(this::addToCreativeTabs);
        NeoForge.EVENT_BUS.addListener(this::onEntityJoin);
    }

    /** Teaches vanilla pigs to eat buffalo dung lying on the ground. */
    private void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (event.getEntity() instanceof Pig pig) {
            boolean has = pig.goalSelector.getAvailableGoals().stream()
                    .anyMatch(w -> w.getGoal() instanceof PigEatDungGoal);
            if (!has) pig.goalSelector.addGoal(5, new PigEatDungGoal(pig));
        }
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(BUFFALO.get(), IraqiBuffalo.createAttributes().build());
    }

    private void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(BUFFALO.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, IraqiBuffalo::checkSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    /** Lets any FE source (cables, generators from other mods) power the pot. */
    private void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, QAYMAR_POT_BE.get(),
                (be, side) -> be.energy);
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, WIND_FAN_BE.get(),
                (be, side) -> be.energy);
    }

    private void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) event.accept(BUFFALO_SPAWN_EGG);
        if (event.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
            event.accept(BUFFALO_MILK_BUCKET);
            event.accept(QAYMAR);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(QAYMAR_POT_ITEM);
            event.accept(WIND_FAN_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) event.accept(BUFFALO_COLLAR);
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) event.accept(BUFFALO_DUNG);
    }
}

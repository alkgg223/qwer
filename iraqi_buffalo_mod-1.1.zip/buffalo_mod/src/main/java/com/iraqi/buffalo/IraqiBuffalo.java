package com.iraqi.buffalo;

import com.iraqi.buffalo.goal.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathType;

import javax.annotation.Nullable;

/**
 * Iraqi water buffalo: 80 HP (4x a player), 12 attack damage (two hits kill an unarmored player),
 * neutral until hit (but hunts zombies), loves shallow water, grazes crops, lies down to rest.
 * A buffalo wearing a bell collar rings when it walks and the whole herd follows it.
 * Adults drop dung from time to time (pigs eat it).
 */
public class IraqiBuffalo extends Animal {
    private static final EntityDataAccessor<Boolean> LYING =
            SynchedEntityData.defineId(IraqiBuffalo.class, EntityDataSerializers.BOOLEAN);

    private static final EntityDataAccessor<Boolean> COLLARED =
            SynchedEntityData.defineId(IraqiBuffalo.class, EntityDataSerializers.BOOLEAN);
    private static final TagKey<Biome> NO_SPAWN_BIOMES =
            TagKey.create(Registries.BIOME, ResourceLocation.fromNamespaceAndPath(IraqiBuffaloMod.MODID, "no_buffalo"));

    private int dungTimer;
    private int bellCooldown;

    public float lieAnim;
    public float lieAnimO;
    private int eatAnimationTick;
    private int milkCooldown;

    public IraqiBuffalo(EntityType<? extends IraqiBuffalo> type, Level level) {
        super(type, level);
        this.setPathfindingMalus(PathType.WATER, 0.0F);
        this.setPathfindingMalus(PathType.WATER_BORDER, 0.0F);
        this.dungTimer = 2400 + this.random.nextInt(2400);
    }

    /** Natural spawns: not in deserts or snowy biomes, and only close to water. */
    public static boolean checkSpawnRules(EntityType<IraqiBuffalo> type, ServerLevelAccessor level,
                                          MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (!Animal.checkAnimalSpawnRules(type, level, reason, pos, random)) return false;
        if (reason != MobSpawnType.NATURAL && reason != MobSpawnType.CHUNK_GENERATION) return true;
        if (level.getBiome(pos).is(NO_SPAWN_BIOMES)) return false;
        return isNearWater(level, pos, 8);
    }

    private static boolean isNearWater(ServerLevelAccessor level, BlockPos pos, int radius) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dx = -radius; dx <= radius; dx += 2) {
            for (int dz = -radius; dz <= radius; dz += 2) {
                p.set(pos.getX() + dx, pos.getY(), pos.getZ() + dz);
                if (!level.hasChunkAt(p)) continue;
                for (int dy = -3; dy <= 2; dy++) {
                    p.setY(pos.getY() + dy);
                    if (level.getFluidState(p).is(FluidTags.WATER)) return true;
                }
            }
        }
        return false;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 80.0D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 24.0D)
                .add(Attributes.STEP_HEIGHT, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.3D, true));
        this.goalSelector.addGoal(2, new BreedGoal(this, 1.0D));
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.15D,
                Ingredient.of(Items.WHEAT, Items.CARROT, Items.POTATO, Items.BEETROOT, Items.HAY_BLOCK), false));
        this.goalSelector.addGoal(4, new FollowParentGoal(this, 1.1D));
        this.goalSelector.addGoal(4, new BuffaloEatItemGoal(this, 1.1D));
        this.goalSelector.addGoal(5, new BuffaloEatCropsGoal(this));
        this.goalSelector.addGoal(5, new BuffaloFollowLeaderGoal(this, 1.1D));
        this.goalSelector.addGoal(6, new BuffaloLieDownGoal(this));
        this.goalSelector.addGoal(7, new BuffaloGoToWaterGoal(this, 1.0D));
        this.goalSelector.addGoal(8, new BuffaloStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(10, new RandomLookAroundGoal(this));

        // neutral: fights back (and its herd helps) ...
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this).setAlertOthers());
        // ... but hunts zombies (all variants except the neutral zombified piglins) on sight
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Zombie.class, 10, true, false,
                (LivingEntity e) -> !this.isBaby() && !(e instanceof ZombifiedPiglin)));
    }

    public static boolean isBuffaloFood(ItemStack stack) {
        return stack.is(Items.WHEAT) || stack.is(Items.CARROT) || stack.is(Items.POTATO)
                || stack.is(Items.BEETROOT) || stack.is(Items.HAY_BLOCK);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return isBuffaloFood(stack);
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
        return IraqiBuffaloMod.BUFFALO.get().create(level);
    }

    // ---------- lying down ----------
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(LYING, false);
        builder.define(COLLARED, false);
    }

    public boolean hasCollar() {
        return this.entityData.get(COLLARED);
    }

    public void setCollared(boolean collared) {
        this.entityData.set(COLLARED, collared);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Collared", this.hasCollar());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setCollared(tag.getBoolean("Collared"));
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        if (this.hasCollar()) this.spawnAtLocation(new ItemStack(IraqiBuffaloMod.BUFFALO_COLLAR.get()));
    }

    public boolean isLying() {
        return this.entityData.get(LYING);
    }

    public void setLying(boolean lying) {
        this.entityData.set(LYING, lying);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.milkCooldown > 0) this.milkCooldown--;
        if (this.bellCooldown > 0) this.bellCooldown--;
        this.lieAnimO = this.lieAnim;
        if (this.isLying()) {
            this.lieAnim = Math.min(1.0F, this.lieAnim + 0.06F);
        } else {
            this.lieAnim = Math.max(0.0F, this.lieAnim - 0.06F);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isLying()) this.setLying(false);
        return super.hurt(source, amount);
    }

    // ---------- eating ----------
    public void onAte(float healAmount) {
        this.heal(healAmount);
        this.playSound(SoundEvents.GENERIC_EAT, 1.0F, 1.0F);
        this.level().broadcastEntityEvent(this, (byte) 10);
        this.tryAutoBreed();
    }

    /** After grazing, the buffalo falls in love by itself and pairs up with a neighbour, so herds grow on their own. */
    private void tryAutoBreed() {
        if (this.level().isClientSide || this.isBaby() || this.getAge() != 0 || !this.canFallInLove()) return;
        int herd = this.level().getEntitiesOfClass(IraqiBuffalo.class, this.getBoundingBox().inflate(24.0D)).size();
        if (herd > 10) return; // population cap
        this.setInLove(null);
        for (IraqiBuffalo other : this.level().getEntitiesOfClass(IraqiBuffalo.class,
                this.getBoundingBox().inflate(8.0D),
                o -> o != this && !o.isBaby() && o.getAge() == 0 && o.canFallInLove())) {
            other.setInLove(null);
            break;
        }
    }

    // ---------- milking ----------
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.is(IraqiBuffaloMod.BUFFALO_COLLAR.get()) && !this.hasCollar()) {
            if (!this.level().isClientSide) {
                this.setCollared(true);
                if (!player.getAbilities().instabuild) stack.shrink(1);
                this.playSound(IraqiBuffaloMod.COLLAR_BELL.get(), 0.8F, 1.0F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (stack.is(Items.SHEARS) && player.isShiftKeyDown() && this.hasCollar()) {
            if (!this.level().isClientSide) {
                this.setCollared(false);
                this.spawnAtLocation(new ItemStack(IraqiBuffaloMod.BUFFALO_COLLAR.get()));
                stack.hurtAndBreak(1, player,
                        hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (stack.is(net.minecraft.world.item.Items.BUCKET) && !this.isBaby() && this.milkCooldown <= 0) {
            player.playSound(SoundEvents.COW_MILK, 1.0F, 0.9F);
            ItemStack filled = ItemUtils.createFilledResult(stack, player,
                    new ItemStack(IraqiBuffaloMod.BUFFALO_MILK_BUCKET.get()));
            player.setItemInHand(hand, filled);
            this.milkCooldown = 2400; // 2 minutes between milkings
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 10) {
            this.eatAnimationTick = 40;
        } else {
            super.handleEntityEvent(id);
        }
    }

    @Override
    public void aiStep() {
        if (this.level().isClientSide) {
            this.eatAnimationTick = Math.max(0, this.eatAnimationTick - 1);
        } else if (this.isAlive() && !this.isBaby() && --this.dungTimer <= 0) {
            this.dungTimer = 2400 + this.random.nextInt(2400);   // every 2-4 minutes
            this.spawnAtLocation(new ItemStack(IraqiBuffaloMod.BUFFALO_DUNG.get()));
            this.playSound(SoundEvents.MUD_PLACE, 0.8F, 0.8F);
        }
        super.aiStep();
    }

    /** 0..1 how far the head is lowered while grazing. */
    public float getEatAnim() {
        int t = this.eatAnimationTick;
        if (t <= 0) return 0.0F;
        if (t > 36) return (40 - t) / 4.0F;
        if (t < 4) return t / 4.0F;
        return 1.0F;
    }

    // ---------- sounds ----------
    @Override
    protected SoundEvent getAmbientSound() {
        return IraqiBuffaloMod.BUFFALO_AMBIENT.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return IraqiBuffaloMod.BUFFALO_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return IraqiBuffaloMod.BUFFALO_DEATH.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.COW_STEP, 0.2F, 0.8F);
        if (this.hasCollar() && this.bellCooldown <= 0) {
            this.playSound(IraqiBuffaloMod.COLLAR_BELL.get(), 0.9F, 0.9F + this.random.nextFloat() * 0.2F);
            this.bellCooldown = 25;
        }
    }
}

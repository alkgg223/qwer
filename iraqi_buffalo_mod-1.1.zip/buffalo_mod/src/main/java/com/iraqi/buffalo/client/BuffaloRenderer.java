package com.iraqi.buffalo.client;

import com.iraqi.buffalo.IraqiBuffalo;
import com.iraqi.buffalo.IraqiBuffaloMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BuffaloRenderer extends MobRenderer<IraqiBuffalo, BuffaloModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(IraqiBuffaloMod.MODID, "textures/entity/buffalo.png");

    public BuffaloRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new BuffaloModel(ctx.bakeLayer(BuffaloModel.LAYER_LOCATION)), 0.9F);
    }

    @Override
    protected void scale(IraqiBuffalo entity, PoseStack poseStack, float partialTick) {
        if (entity.isBaby()) poseStack.scale(0.5F, 0.5F, 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(IraqiBuffalo entity) {
        return TEXTURE;
    }
}

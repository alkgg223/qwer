package com.iraqi.buffalo.goal;

import com.iraqi.buffalo.IraqiBuffalo;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;

import java.util.EnumSet;

/** Walks into nearby shallow water when it is on dry land (the buffalo loves ponds and swamps). */
public class BuffaloGoToWaterGoal extends Goal {
    private final IraqiBuffalo buffalo;
    private final double speed;
    private BlockPos waterPos;

    public BuffaloGoToWaterGoal(IraqiBuffalo buffalo, double speed) {
        this.buffalo = buffalo;
        this.speed = speed;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (buffalo.isInWater() || buffalo.isLying() || buffalo.getTarget() != null) return false;
        if (buffalo.getRandom().nextInt(80) != 0) return false;
        waterPos = findWater();
        return waterPos != null;
    }

    @Override
    public boolean canContinueToUse() {
        return !buffalo.getNavigation().isDone() && !buffalo.isInWater() && buffalo.getTarget() == null;
    }

    @Override
    public void start() {
        buffalo.getNavigation().moveTo(waterPos.getX() + 0.5D, waterPos.getY(), waterPos.getZ() + 0.5D, speed);
    }

    private BlockPos findWater() {
        Level level = buffalo.level();
        RandomSource random = buffalo.getRandom();
        BlockPos origin = buffalo.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (int i = 0; i < 48; i++) {
            BlockPos p = origin.offset(random.nextInt(29) - 14, random.nextInt(7) - 3, random.nextInt(29) - 14);
            boolean water = level.getFluidState(p).is(FluidTags.WATER);
            boolean shallow = !level.getFluidState(p.below()).is(FluidTags.WATER)
                    && level.getBlockState(p.above()).isAir();
            if (water && shallow) {
                double d = p.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = p;
                }
            }
        }
        return best;
    }
}

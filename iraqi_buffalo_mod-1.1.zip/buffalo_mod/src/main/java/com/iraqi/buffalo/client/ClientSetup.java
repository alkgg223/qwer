package com.iraqi.buffalo.client;

import com.iraqi.buffalo.IraqiBuffaloMod;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = IraqiBuffaloMod.MODID, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(BuffaloModel.LAYER_LOCATION, BuffaloModel::createBodyLayer);
        event.registerLayerDefinition(QaymarPotRenderer.LAYER, QaymarPotRenderer::createLayer);
        event.registerLayerDefinition(WindFanRenderer.LAYER, WindFanRenderer::createLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(IraqiBuffaloMod.BUFFALO.get(), BuffaloRenderer::new);
        event.registerBlockEntityRenderer(IraqiBuffaloMod.QAYMAR_POT_BE.get(), QaymarPotRenderer::new);
        event.registerBlockEntityRenderer(IraqiBuffaloMod.WIND_FAN_BE.get(), WindFanRenderer::new);
    }
}

package com.iraqi.buffalo;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * Electric rotating Qaymar pot.
 * stage 0 = empty, 1 = buffalo milk inside, 2 = qaymar ready (take it with bowls).
 * Needs a heat source directly underneath and power (redstone signal or FE).
 */
public class QaymarPotBlock extends BaseEntityBlock {
    public static final MapCodec<QaymarPotBlock> CODEC = simpleCodec(QaymarPotBlock::new);
    public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, 2);
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public QaymarPotBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(STAGE, 0).setValue(LIT, false));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(STAGE, LIT);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new QaymarPotBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return createTickerHelper(type, IraqiBuffaloMod.QAYMAR_POT_BE.get(), QaymarPotBlockEntity::clientTick);
        }
        return createTickerHelper(type, IraqiBuffaloMod.QAYMAR_POT_BE.get(), QaymarPotBlockEntity::serverTick);
    }

    /** Campfires, magma, lava, fire and lit furnaces count as heat. */
    public static boolean isHeatSource(Level level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        if (s.is(Blocks.MAGMA_BLOCK) || s.is(Blocks.LAVA) || s.is(BlockTags.FIRE)) return true;
        if (s.is(BlockTags.CAMPFIRES) && s.hasProperty(CampfireBlock.LIT)) return s.getValue(CampfireBlock.LIT);
        if (s.is(Blocks.FURNACE) || s.is(Blocks.BLAST_FURNACE) || s.is(Blocks.SMOKER)) {
            return s.hasProperty(BlockStateProperties.LIT) && s.getValue(BlockStateProperties.LIT);
        }
        return false;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        int stage = state.getValue(STAGE);
        BlockEntity be = level.getBlockEntity(pos);

        if (stage == 0 && stack.is(IraqiBuffaloMod.BUFFALO_MILK_BUCKET.get())) {
            if (!level.isClientSide) {
                player.setItemInHand(hand, ItemUtils.createFilledResult(stack, player, new ItemStack(Items.BUCKET)));
                level.setBlock(pos, state.setValue(STAGE, 1), 3);
                if (be instanceof QaymarPotBlockEntity pot) pot.resetProgress();
                level.playSound(null, pos, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        if (stage == 2 && stack.is(Items.BOWL) && be instanceof QaymarPotBlockEntity pot) {
            if (!level.isClientSide) {
                player.setItemInHand(hand, ItemUtils.createFilledResult(stack, player,
                        new ItemStack(IraqiBuffaloMod.QAYMAR.get())));
                int left = pot.getPortions() - 1;
                pot.setPortions(Math.max(0, left));
                if (left <= 0) level.setBlock(pos, state.setValue(STAGE, 0).setValue(LIT, false), 3);
                level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hit) {
        if (!level.isClientSide) {
            int stage = state.getValue(STAGE);
            BlockEntity be = level.getBlockEntity(pos);
            Component msg;
            if (stage == 0) {
                msg = Component.translatable("message.iraqi_buffalo.pot_empty");
            } else if (stage == 2 && be instanceof QaymarPotBlockEntity pot) {
                msg = Component.translatable("message.iraqi_buffalo.pot_ready", pot.getPortions());
            } else if (!isHeatSource(level, pos.below())) {
                msg = Component.translatable("message.iraqi_buffalo.pot_need_heat");
            } else if (be instanceof QaymarPotBlockEntity pot && !pot.hasPower(level, pos)) {
                msg = Component.translatable("message.iraqi_buffalo.pot_need_power");
            } else if (be instanceof QaymarPotBlockEntity pot) {
                msg = Component.translatable("message.iraqi_buffalo.pot_cooking", pot.getProgressPercent());
            } else {
                return InteractionResult.PASS;
            }
            player.displayClientMessage(msg, true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (state.getValue(LIT) && random.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.CLOUD,
                    pos.getX() + 0.3D + random.nextDouble() * 0.4D, pos.getY() + 0.75D,
                    pos.getZ() + 0.3D + random.nextDouble() * 0.4D, 0.0D, 0.03D, 0.0D);
        }
    }
}

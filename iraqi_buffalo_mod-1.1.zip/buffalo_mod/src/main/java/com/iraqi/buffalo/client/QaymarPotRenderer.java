package com.iraqi.buffalo.client;

import com.iraqi.buffalo.IraqiBuffaloMod;
import com.iraqi.buffalo.QaymarPotBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Draws the spinning paddle inside the qaymar pot. */
public class QaymarPotRenderer implements BlockEntityRenderer<QaymarPotBlockEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(IraqiBuffaloMod.MODID, "qaymar_paddle"), "main");
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(IraqiBuffaloMod.MODID, "textures/block/qaymar_paddle.png");

    private final ModelPart paddle;

    public QaymarPotRenderer(BlockEntityRendererProvider.Context ctx) {
        this.paddle = ctx.bakeLayer(LAYER).getChild("paddle");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        mesh.getRoot().addOrReplaceChild("paddle", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-1.0F, -15.0F, -1.0F, 2.0F, 12.0F, 2.0F)
                .texOffs(10, 0).addBox(-3.5F, -8.0F, -0.5F, 7.0F, 4.0F, 1.0F)
                .texOffs(10, 6).addBox(-0.5F, -8.0F, -3.5F, 1.0F, 4.0F, 7.0F), PartPose.ZERO);
        return LayerDefinition.create(mesh, 32, 32);
    }

    @Override
    public void render(QaymarPotBlockEntity be, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight, int packedOverlay) {
        float angle = Mth.lerp(partialTick, be.angleO, be.angle);
        poseStack.pushPose();
        poseStack.translate(0.5D, 0.0D, 0.5D);
        poseStack.mulPose(Axis.YP.rotationDegrees(angle));
        poseStack.scale(1.0F, -1.0F, -1.0F);
        this.paddle.render(poseStack, buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)),
                packedLight, packedOverlay);
        poseStack.popPose();
    }
}

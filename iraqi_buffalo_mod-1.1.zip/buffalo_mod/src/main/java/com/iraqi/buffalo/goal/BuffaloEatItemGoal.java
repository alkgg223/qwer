package com.iraqi.buffalo.goal;

import com.iraqi.buffalo.IraqiBuffalo;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Walks to food items lying on the ground (wheat, carrot, potato, beetroot, hay) and eats them. */
public class BuffaloEatItemGoal extends Goal {
    private final IraqiBuffalo buffalo;
    private final double speed;
    private ItemEntity target;

    public BuffaloEatItemGoal(IraqiBuffalo buffalo, double speed) {
        this.buffalo = buffalo;
        this.speed = speed;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (buffalo.isLying() || buffalo.getTarget() != null) return false;
        if (buffalo.getRandom().nextInt(10) != 0) return false;
        List<ItemEntity> list = buffalo.level().getEntitiesOfClass(ItemEntity.class,
                buffalo.getBoundingBox().inflate(10.0D, 3.0D, 10.0D),
                e -> e.isAlive() && IraqiBuffalo.isBuffaloFood(e.getItem()));
        if (list.isEmpty()) return false;
        list.sort(Comparator.comparingDouble(buffalo::distanceToSqr));
        target = list.get(0);
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && !buffalo.isLying() && buffalo.getTarget() == null;
    }

    @Override
    public void start() {
        buffalo.getNavigation().moveTo(target, speed);
    }

    @Override
    public void stop() {
        target = null;
        buffalo.getNavigation().stop();
    }

    @Override
    public void tick() {
        buffalo.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (buffalo.distanceToSqr(target) < 6.25D) {
            ItemStack stack = target.getItem();
            stack.shrink(1);
            if (stack.isEmpty()) {
                target.discard();
            } else {
                target.setItem(stack);
            }
            buffalo.onAte(4.0F);
            target = null;
        } else if (buffalo.getNavigation().isDone()) {
            buffalo.getNavigation().moveTo(target, speed);
        }
    }
}

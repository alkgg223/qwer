package com.iraqi.buffalo.goal;

import com.iraqi.buffalo.IraqiBuffalo;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;

/** Normal wandering, but it mostly stays put while standing in water. */
public class BuffaloStrollGoal extends RandomStrollGoal {
    private final IraqiBuffalo buffalo;

    public BuffaloStrollGoal(IraqiBuffalo buffalo, double speed) {
        super(buffalo, speed, 120);
        this.buffalo = buffalo;
    }

    @Override
    public boolean canUse() {
        if (buffalo.isLying()) return false;
        if (buffalo.isInWater() && buffalo.getRandom().nextInt(4) != 0) return false;
        return super.canUse();
    }
}

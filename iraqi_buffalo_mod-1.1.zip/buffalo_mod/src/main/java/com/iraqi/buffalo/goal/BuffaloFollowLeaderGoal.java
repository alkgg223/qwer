package com.iraqi.buffalo.goal;

import com.iraqi.buffalo.IraqiBuffalo;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Every buffalo follows the nearest buffalo that wears a bell collar. */
public class BuffaloFollowLeaderGoal extends Goal {
    private final IraqiBuffalo buffalo;
    private final double speed;
    private IraqiBuffalo leader;
    private int recalc;

    public BuffaloFollowLeaderGoal(IraqiBuffalo buffalo, double speed) {
        this.buffalo = buffalo;
        this.speed = speed;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (buffalo.hasCollar() || buffalo.isLying() || buffalo.getTarget() != null || buffalo.isInLove()) return false;
        if (buffalo.getRandom().nextInt(10) != 0) return false;
        List<IraqiBuffalo> leaders = buffalo.level().getEntitiesOfClass(IraqiBuffalo.class,
                buffalo.getBoundingBox().inflate(40.0D, 16.0D, 40.0D),
                b -> b != buffalo && b.isAlive() && b.hasCollar());
        if (leaders.isEmpty()) return false;
        IraqiBuffalo nearest = leaders.stream().min(Comparator.comparingDouble(buffalo::distanceToSqr)).get();
        if (buffalo.distanceToSqr(nearest) < 25.0D) return false; // already close enough
        leader = nearest;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (leader == null || !leader.isAlive() || buffalo.isLying() || buffalo.getTarget() != null) return false;
        double d = buffalo.distanceToSqr(leader);
        return d > 9.0D && d < 48.0D * 48.0D;
    }

    @Override
    public void start() {
        recalc = 0;
    }

    @Override
    public void stop() {
        leader = null;
        buffalo.getNavigation().stop();
    }

    @Override
    public void tick() {
        buffalo.getLookControl().setLookAt(leader, 10.0F, buffalo.getMaxHeadXRot());
        if (--recalc <= 0) {
            recalc = adjustedTickDelay(10);
            buffalo.getNavigation().moveTo(leader, speed);
        }
    }
}

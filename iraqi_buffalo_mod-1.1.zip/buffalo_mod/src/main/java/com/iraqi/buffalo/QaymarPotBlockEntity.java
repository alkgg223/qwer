package com.iraqi.buffalo;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class QaymarPotBlockEntity extends BlockEntity {
    public static final int ENERGY_PER_TICK = 20;   // FE/t when powered by energy instead of redstone
    public static final int COOK_TIME = 240;        // 12 seconds
    public static final int PORTIONS = 4;           // bowls of qaymar per bucket of milk

    public final PotEnergy energy = new PotEnergy(20000, 2000);
    private int progress;
    private int portions;

    // client-side paddle animation
    public float angle;
    public float angleO;

    public QaymarPotBlockEntity(BlockPos pos, BlockState state) {
        super(IraqiBuffaloMod.QAYMAR_POT_BE.get(), pos, state);
    }

    public int getProgressPercent() {
        return progress * 100 / COOK_TIME;
    }

    public int getPortions() {
        return portions;
    }

    public void setPortions(int value) {
        this.portions = value;
        this.setChanged();
    }

    public void resetProgress() {
        this.progress = 0;
        this.setChanged();
    }

    /** The pot is "electric": it runs from a redstone signal or from FE. */
    public boolean hasPower(Level level, BlockPos pos) {
        return level.hasNeighborSignal(pos) || this.energy.getEnergyStored() >= ENERGY_PER_TICK;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, QaymarPotBlockEntity be) {
        boolean milk = state.getValue(QaymarPotBlock.STAGE) == 1;
        boolean heat = QaymarPotBlock.isHeatSource(level, pos.below());
        boolean redstone = level.hasNeighborSignal(pos);
        boolean powered = redstone || be.energy.getEnergyStored() >= ENERGY_PER_TICK;
        boolean running = milk && heat && powered;

        if (running) {
            if (!redstone) be.energy.consume(ENERGY_PER_TICK);
            be.progress++;
            if (be.progress >= COOK_TIME) {
                be.progress = 0;
                be.portions = PORTIONS;
                level.setBlock(pos, state.setValue(QaymarPotBlock.STAGE, 2).setValue(QaymarPotBlock.LIT, false), 3);
                level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0F, 1.0F);
            } else if (!state.getValue(QaymarPotBlock.LIT)) {
                level.setBlock(pos, state.setValue(QaymarPotBlock.LIT, true), 3);
            }
            if (be.progress % 40 == 0) {
                level.playSound(null, pos, SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT, SoundSource.BLOCKS, 0.5F, 1.0F);
            }
            be.setChanged();
        } else {
            if (state.getValue(QaymarPotBlock.LIT)) {
                level.setBlock(pos, state.setValue(QaymarPotBlock.LIT, false), 3);
            }
            if (be.progress > 0 && milk) be.progress--;
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, QaymarPotBlockEntity be) {
        be.angleO = be.angle;
        if (state.getValue(QaymarPotBlock.LIT)) {
            be.angle = (be.angle + 14.0F) % 360.0F;
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Progress", this.progress);
        tag.putInt("Portions", this.portions);
        tag.putInt("Energy", this.energy.getEnergyStored());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.progress = tag.getInt("Progress");
        this.portions = tag.getInt("Portions");
        this.energy.setEnergy(tag.getInt("Energy"));
    }
}

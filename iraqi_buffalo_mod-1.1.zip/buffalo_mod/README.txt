Iraqi Buffalo mod - Minecraft 1.21.1 / NeoForge 21.1.264
Build: copy gradlew + gradle/wrapper from the official NeoForge 1.21.1 MDK into this folder, then run ./gradlew build
Jar: build/libs/iraqi_buffalo-1.1.0.jar
